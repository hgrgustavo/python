"""
treeview event

see more about bind on docs

"""


def selecionacidade(self, event):
    seleciona_item = self.tree.selection()

    if seleciona_item:
        # Obtém o item selecionado
        item = seleciona_item[0]
        values = self.tree.item(item, 'values')

        # Preenche os campos de entrada com os dados do item selecionado
        self.idcidade.delete(0, END)
        self.idcidade.insert(INSERT, values[0])
        self.cidade.delete(0, END)
        self.cidade.insert(INSERT, values[1])
        self.uf.delete(0, END)
        self.uf.insert(INSERT, values[2])

        # bind event
        # self.tree.bind("<<TreeviewSelect>>", self.selecionacidade)